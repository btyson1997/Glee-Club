//
//  CommentController.swift
//  book
//
//  Created by Hugo Gomes Alves Da Silva on 12/10/19.
//  Copyright © 2019 Hugo Gomes Alves Da Silva. All rights reserved.
//

import UIKit

class CommentController: UIViewController {
    var commen: String = ""
    
    @IBOutlet weak var commentName: UITextField!
    //@IBOutlet weak var commentName2: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //@IBOutlet weak var commentName: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneSegue" {
            print("hasd")
            commen = commentName.text!
        }
    }    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
